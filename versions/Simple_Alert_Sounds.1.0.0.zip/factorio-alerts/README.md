# factorio-alerts

A simple mod that adds in a couple selectable sound from Star Craft to play with programmable speakers.


